﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GlobalController : MonoBehaviour
{
    public float DeadTime;
    [SerializeField] private GameObject _playerPrefab;
    [SerializeField] private Cinemachine.CinemachineVirtualCamera cam;
    [SerializeField] private Camera cam1;
    private GameObject _currentPlayer;

    public Vector3 startPosition;
    public int health;

    // Start is called before the first frame update
    void Start()
    {
        Revive();
        StartCoroutine(DeadTimeCount());
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void Revive()
    {
        Revive(startPosition, 0);
    }

    public void Revive(Vector3 position)
    {
        Revive(position, 0);
    }

    public void Revive(Vector3 position, int level)
    {
        _currentPlayer = Instantiate(_playerPrefab, position, Quaternion.Euler(new Vector3(0, 0, 0)));
        cam.m_Follow = _currentPlayer.transform;
        RestoreAbility(level);
        StartCoroutine(DeadTimeCount());
    }

    public void ResetPosition(Vector3 position)
    {
        if (_currentPlayer)
        {
            _currentPlayer.transform.position = position;
        }
    }


    public void Recover()
    {
        if (_currentPlayer)
        {
            _currentPlayer.gameObject.GetComponent<PlayerController>().Recover(health);
        }

        StopCoroutine(DeadTimeCount());
        StartCoroutine(DeadTimeCount());
    }

    private void RestoreAbility(int level)
    {
        if (_currentPlayer)
        {
            _currentPlayer.gameObject.GetComponent<PlayerController>().RestoreAbility(level);
        }
    }

    private IEnumerator DeadTimeCount()
    {
        float totalTime = DeadTime;
        while (totalTime >= 0)
        {
            // TODO: 此处输出倒计时时间

            yield return new WaitForSeconds(1);
            totalTime -= 1;
        }

        Destroy(_currentPlayer.gameObject);
    }

    public Camera GetCamera() // 传递镜头
    {
        return cam1;
    }
}